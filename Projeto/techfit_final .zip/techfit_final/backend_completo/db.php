<?php
$host = "localhost";
$user = "seu_usuario";
$pass = "sua_senha";
$db   = "techfit";

$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
    die(json_encode(["success" => false, "error" => "Erro: " . $conn->connect_error]));
}
$conn->set_charset("utf8");
?>