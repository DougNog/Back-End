CREATE DATABASE IF NOT EXISTS techfit;
USE techfit;

-- ========================
-- Tabela de acessos (login)
-- ========================
CREATE TABLE acessos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(100) NOT NULL,
    senha VARCHAR(255) NOT NULL,
    nome VARCHAR(100),
    email VARCHAR(100)
);

-- Usuário inicial: admin / 1234
INSERT INTO acessos (username, senha, nome, email)
VALUES ('admin', '1234', 'Administrador', 'admin@techfit.com');

-- ========================
-- Tabela de membros
-- ========================
CREATE TABLE membros (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL,
    modalidade VARCHAR(100),
    freq INT DEFAULT 0
);

-- ========================
-- Tabela de turmas
-- ========================
CREATE TABLE turmas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    horario VARCHAR(50),
    instrutor VARCHAR(100)
);

-- ========================
-- Tabela de reservas
-- ========================
CREATE TABLE reservas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    id_membro INT,
    id_turma INT,
    data_reserva DATE,
    FOREIGN KEY (id_membro) REFERENCES membros(id),
    FOREIGN KEY (id_turma) REFERENCES turmas(id)
);

-- ========================
-- Tabela de mensagens
-- ========================
CREATE TABLE mensagens (
    id INT AUTO_INCREMENT PRIMARY KEY,
    id_membro INT,
    mensagem TEXT,
    data_envio DATETIME,
    FOREIGN KEY (id_membro) REFERENCES membros(id)
);

-- ========================
-- Tabela de tickets
-- ========================
CREATE TABLE tickets (
    id INT AUTO_INCREMENT PRIMARY KEY,
    id_membro INT,
    assunto VARCHAR(200),
    status VARCHAR(50) DEFAULT 'aberto',
    data_criacao DATETIME,
    FOREIGN KEY (id_membro) REFERENCES membros(id)
);

-- ========================
-- Tabela de avaliações
-- ========================
CREATE TABLE avaliacoes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    id_membro INT,
    nota INT,
    comentario TEXT,
    data_avaliacao DATETIME,
    FOREIGN KEY (id_membro) REFERENCES membros(id)
);
